=== Plugin Name ===
Contributors: mRova
Tags: WooCommerce, Cloud Zoom
Requires at least: 3.3
Tested up to: 3.3
Stable tag: 0.1

Cloud Zoom for woocommerce uses Cloud Zoom jQuery image zoom plugin

== Description ==

This is the Cloud Zoom plugin for WooCommerce. It gives the ability to users to zoom in on your main product image by simply hovering the mouse over it.

Visit [http://www.mrova.com/woocommerce-cloud-zoom/](http://www.mrova.com/woocommerce-cloud-zoom/)
== Installation ==
1. Ensure you have latest version of WooCommerce plugin installed
2. Unzip and upload contents of the plugin to your /wp-content/plugins/ directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. Cloud Zoom frontend
2. Cloud Zoom Admin

== Changelog ==

= 0.1 =
* First Public Release.

